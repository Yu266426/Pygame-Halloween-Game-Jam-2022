import os

CURRENT_DIR = os.getcwd()
DATA_DIR = os.path.join(CURRENT_DIR, "data")
ASSET_DIR = os.path.join(DATA_DIR, "assets")
